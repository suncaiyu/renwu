#ifndef BASEPLOT_H
#define BASEPLOT_H

#include <QWidget>

#include "qcustomplot.h"

/// ������ͼ�����࣬�ṩ��ͼ����(gui)�ӿ�

class QCPAxis;
class QCPGraph;
class QCustomPlot;

class BasePlot : public QWidget
{
	Q_OBJECT

public:
	BasePlot(QWidget * parent = nullptr);
	~BasePlot();

public:
	//operate gui interface
	void SetPen(const QPen & pen, QCPGraph * graph = nullptr);
	void SetBrush(const QBrush & pen, QCPGraph * graph = nullptr);

	QCPAxis * GetAxis(QCPAxis::AxisType axis);

	void SetGridVisible(bool visible);
	void SetAxisPen(QCPAxis::AxisTypes axse, const QPen & pen);
	void SetAxisTickStep(QCPAxis::AxisTypes axse, int step);
	void SetAxisPadding(QCPAxis::AxisType type, int padding);

	//������ͬ��ע��ӿ�
	bool RegisiterBrotherRange(QCPAxis::AxisType type, BasePlot * plot);
	bool UnregisiterBrotherRange(QCPAxis::AxisType type, BasePlot * plot);

	//interface
	virtual void SyncAxisRange(QCPAxis::AxisType type, const QCPRange & range) = 0;
	virtual void MoveTipLabel(const QPoint & pos) = 0;

private:
	void InitializeUI();

protected:
	QCustomPlot * m_pPlot = nullptr;
	static std::map<QCPAxis::AxisType, std::vector<BasePlot *>> m_BrotherAxisRange;
};

#endif // BASEPLOT_H
