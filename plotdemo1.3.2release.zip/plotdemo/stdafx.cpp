#include "stdafx.h"

void FindNearlyindex(double min, double max, double step, double value, double & resultValue)
{
	Q_ASSERT(step != 0);

	if (value <= min)
	{
		resultValue = min;
		return;
	}
	if (value >= max)
	{
		resultValue = max;
		return;
	}
	double key = (value - min) * 1.0 / step;
	if (qCeil(key) - key > key - qFloor(key))
	{
		resultValue = min + qFloor(key) * step;
	}
	else
	{
		resultValue = min + qCeil(key) * step;
	}
}
