#ifndef QCPCROSSLINE_H
#define QCPCROSSLINE_H

#include <memory>

#include <QtCore/QString>

#include "qcustomplot.h"

class BasePlot;


/// ������ʮ������ 

class CrossLinePlot : public  QCPLayerable
{
	Q_OBJECT
signals :
	void DrawCrossLine(const QPoint & pos);

public:
	CrossLinePlot(BasePlot * basePlot, QCustomPlot * plot);
	~CrossLinePlot();

public:
	QString LayerName() const;
	void SetVisible(bool visible);//���ò��Ƿ����

	void SetPen(const QPen & pen);

	bool MouseButtonDown() const ;
	bool GetLineVisible(Qt::Orientation orientation) const;
	void SetLineVisible(Qt::Orientation orientation, bool visible);

	//ʮ����ͬ��ע��ӿ�
	bool RegisiterBortherLine(CrossLinePlot * line);
	bool UnregisiterBortherLine(CrossLinePlot * line);

protected:
	virtual void applyDefaultAntialiasingHint(QCPPainter *painter) const{};
	virtual void draw(QCPPainter * painter);

private:
	void DrawLine(QCPAxis * axis, Qt::Orientation orientation);
	void SyncLinePosition(const QPoint & pos, double x);

private:
	struct CrossLinePlotPrivate;
	std::unique_ptr<CrossLinePlotPrivate> _p;
	static std::vector<CrossLinePlot *> m_BrotherLine;
};

#endif // QCPCROSSLINE_H
