#include "stdafx.h"

#include "qcustomplot.h"
#include "CrossLinePlot.h"

#include "GraphPlot.h"

struct GraphPlot::GraphPlotPrivate
{
	QLabel * m_LeftAxisTip = nullptr;
	QLabel * m_RightAxisTip = nullptr;
	QLabel * m_BottomAxisTip = nullptr;

	CrossLinePlot * m_pCrossLine = nullptr;
};

GraphPlot::GraphPlot(QWidget * parent)
	: BasePlot(parent)
	, _p(new GraphPlotPrivate)
{
	_p->m_pCrossLine = new CrossLinePlot(this, m_pPlot);

	connect(m_pPlot->xAxis, static_cast<void (QCPAxis:: *)(const QCPRange &)>(&QCPAxis::rangeChanged), this, [this](const QCPRange & range){
	//	if (_p->m_pCrossLine->MouseButtonDown())
		{
			AxisRangeChanged(QCPAxis::atBottom, range);
		}
	}); 
}

GraphPlot::~GraphPlot()
{

}

QCPGraph * GraphPlot::GetGraph(int index) const
{
	return m_pPlot->graph(index);
}

QCPGraph * GraphPlot::GetGraph() const
{
	return m_pPlot->graph();
}

QCPGraph * GraphPlot::AddGraph(QCPAxis * keyAxis /*= 0*/, QCPAxis * valueAxis /*= 0*/)
{
	return m_pPlot->addGraph(keyAxis, valueAxis);
}

bool GraphPlot::RemoveGraph(QCPGraph * graph)
{
	return m_pPlot->removeGraph(graph);
}

bool GraphPlot::RemoveGraph(int index)
{
	return m_pPlot->removeGraph(index);
}

bool GraphPlot::RemoveGraph(const QString & name)
{
	return m_pPlot->removeGraph(name);
}

int GraphPlot::ClearGraphs()
{
	return m_pPlot->clearGraphs();
}

int GraphPlot::GraphCount() const
{
	return m_pPlot->graphCount();
}

QList<QCPGraph *> GraphPlot::SelectedGraphs() const
{
	return m_pPlot->selectedGraphs();
}

void GraphPlot::SyncAxisRange(QCPAxis::AxisType type, const QCPRange & range)
{
	GetAxis(type)->setRange(range);
	m_pPlot->replot();
}

void GraphPlot::MoveTipLabel(const QPoint & pos)
{
	if (_p->m_LeftAxisTip == nullptr)
	{
		_p->m_LeftAxisTip = new QLabel(this);
		_p->m_LeftAxisTip->setAttribute(Qt::WA_TransparentForMouseEvents);
		_p->m_LeftAxisTip->setWindowFlags(Qt::WindowStaysOnTopHint);
		_p->m_LeftAxisTip->setAlignment(Qt::AlignCenter);
		_p->m_LeftAxisTip->setFixedSize(60, 20);
		_p->m_LeftAxisTip->setText("<p style='color:red;'>l");
	}
	if (_p->m_RightAxisTip == nullptr)
	{
		_p->m_RightAxisTip = new QLabel(this);
		_p->m_RightAxisTip->setAttribute(Qt::WA_TransparentForMouseEvents);
		_p->m_RightAxisTip->setWindowFlags(Qt::WindowStaysOnTopHint);
		_p->m_RightAxisTip->setAlignment(Qt::AlignCenter);
		_p->m_RightAxisTip->setFixedSize(60, 20);
		_p->m_RightAxisTip->setText("<p style='color:red;'>r");
	}
	if (_p->m_BottomAxisTip == nullptr)
	{
		_p->m_BottomAxisTip = new QLabel(this);
		_p->m_BottomAxisTip->setAttribute(Qt::WA_TransparentForMouseEvents);
		_p->m_BottomAxisTip->setWindowFlags(Qt::WindowStaysOnTopHint);
		_p->m_BottomAxisTip->setAlignment(Qt::AlignCenter);
		_p->m_BottomAxisTip->setFixedSize(88, 18);
		_p->m_BottomAxisTip->setText("<p style='color:red;'>b");
	}

	_p->m_LeftAxisTip->move(QPoint(0, pos.y() - _p->m_LeftAxisTip->height() / 2));
	_p->m_RightAxisTip->move(QPoint(width() - _p->m_RightAxisTip->width(), pos.y() - _p->m_RightAxisTip->height() / 2));
	_p->m_BottomAxisTip->move(QPoint(pos.x() - _p->m_BottomAxisTip->width() / 2, height() - _p->m_RightAxisTip->height() + 2));
}

void GraphPlot::SetToopTipVisible(QCPAxis::AxisTypes axse, bool visible)
{
	if (axse.testFlag(QCPAxis::atLeft) && _p->m_LeftAxisTip)
	{
		_p->m_LeftAxisTip->setVisible(visible);
	}
	if (axse.testFlag(QCPAxis::atRight) && _p->m_RightAxisTip)
	{
		_p->m_RightAxisTip->setVisible(visible);
	}
	if (axse.testFlag(QCPAxis::atBottom) && _p->m_BottomAxisTip && m_pPlot->xAxis->tickLabels())
	{
		_p->m_BottomAxisTip->setVisible(visible);
	}
}

void GraphPlot::SetGraphData(const std::vector<double> & key, const std::vector<double> & value, QCPGraph * graph)
{
	if (key.size() == 0 || value.size() || key.size() != value.size())
	{
		//������־
		return;
	}
	QVector<double> qkey = QVector<double>::fromStdVector(key);
	QVector<double> qvalue = QVector<double>::fromStdVector(value);
	
	if (graph)
	{
		graph->setData(qkey, qvalue);
	}
	else
	{
		if (m_pPlot->graph())
		{
			m_pPlot->graph()->setData(qkey, qvalue);
		}
		else
		{
			//��ǰ��ͼ��
		}
	}
}

void GraphPlot::AddPointData(double key, double value, QCPGraph * graph)
{
	if (graph)
	{
		graph->addData(key, value);
	}
	else
	{
		if (m_pPlot->graph())
		{
			m_pPlot->graph()->addData(key, value);
		}
	}
}

void GraphPlot::SetPointData(double key, double value, QCPGraph * graph)
{
	if (graph)
	{
		graph->removeData(key);
		graph->addData(value, value);
	}
	else
	{
		if (m_pPlot->graph())
		{
			m_pPlot->graph()->removeData(key);
			m_pPlot->graph()->addData(value, value);
		}
	}
}

void GraphPlot::RemovePointData(double key, QCPGraph * graph /*= nullptr*/)
{
	if (graph)
	{
		graph->removeData(key);
	}
	else
	{
		if (m_pPlot->graph())
		{
			m_pPlot->graph()->removeData(key);
		}
	}
}

void GraphPlot::SetScatterStyle(QCPScatterStyle style, QCPGraph * graph /*= nullptr*/)
{
	if (graph)
	{
		graph->setScatterStyle(style);
	}
	else
	{
		if (m_pPlot->graph())
		{
			m_pPlot->graph()->setScatterStyle(style);
		}
	}
}

void GraphPlot::SetCrossLineVisible(bool visible)
{
	_p->m_pCrossLine->SetVisible(visible);
}

CrossLinePlot * GraphPlot::GetCrossLine() const
{
	return _p->m_pCrossLine;
}

bool GraphPlot::RegisiterBortherLine(CrossLinePlot * line)
{
	return _p->m_pCrossLine->RegisiterBortherLine(line);
}

bool GraphPlot::UnregisiterBortherLine(CrossLinePlot * line)
{
	return _p->m_pCrossLine->UnregisiterBortherLine(line);
}

void GraphPlot::enterEvent(QEvent * event)
{
	__super::enterEvent(event);
}

void GraphPlot::leaveEvent(QEvent * event)
{
	__super::leaveEvent(event);
}

void GraphPlot::AxisRangeChanged(QCPAxis::AxisType type, const QCPRange & range)
{
	if (BasePlot::m_BrotherAxisRange.find(QCPAxis::atBottom) != BasePlot::m_BrotherAxisRange.end())
	{
		for (BasePlot * plot : BasePlot::m_BrotherAxisRange[QCPAxis::atBottom])
		{
			if (plot != this)
			{
				plot->SyncAxisRange(type, range);
			}
		}
	}
}
