#include "stdafx.h"

#include "qcustomplot.h"

#include "BasePlot.h"

namespace
{
    void ConfigureAxis(QCPAxis * axis, bool labelVisible)
    {
	//	axis->setAutoSubTicks(false);
	//	axis->setSubTickCount(0);
        axis->setAutoTickCount(false);
        axis->setAutoTickStep(false);

		axis->setTickLabels(labelVisible);
    }

	void ConfigureZeroLine(QCPAxis * axis)
	{
		axis->grid()->setZeroLinePen(QPen(Qt::NoPen));
		axis->setTickLength(0);
		axis->setTickPen(QPen(Qt::transparent));
		axis->setSubTickPen(QPen(Qt::transparent));
		axis->setBasePen(QPen(Qt::transparent));
	}
}

std::map<QCPAxis::AxisType, std::vector<BasePlot *>>BasePlot::m_BrotherAxisRange;

BasePlot::BasePlot(QWidget * parent)
    : QWidget(parent)
{
    InitializeUI();

	ConfigureAxis(GetAxis(QCPAxis::atLeft), true);
	ConfigureAxis(GetAxis(QCPAxis::atTop), false);
	ConfigureAxis(GetAxis(QCPAxis::atRight), true);
	ConfigureAxis(GetAxis(QCPAxis::atBottom), false);

	SetAxisPadding(QCPAxis::atLeft, 30);
	SetAxisPadding(QCPAxis::atRight, 30);

	//��������
	ConfigureZeroLine(GetAxis(QCPAxis::atLeft));
	ConfigureZeroLine(GetAxis(QCPAxis::atTop));
	ConfigureZeroLine(GetAxis(QCPAxis::atRight));
	ConfigureZeroLine(GetAxis(QCPAxis::atBottom));

	connect(GetAxis(QCPAxis::atLeft), static_cast<void (QCPAxis:: *)(const QCPRange &)>(&QCPAxis::rangeChanged)
		, GetAxis(QCPAxis::atRight), static_cast<void (QCPAxis:: *)(const QCPRange &)>(&QCPAxis::setRange));
}

BasePlot::~BasePlot()
{
    
}

void BasePlot::SetPen(const QPen & pen, QCPGraph * graph /*= nullptr*/)
{
    if (graph)
    {
        graph->setPen(pen);
    }
    else
    {
        if (m_pPlot->graph())
        {
            m_pPlot->graph()->setPen(pen);
        }
    }
}

void BasePlot::SetBrush(const QBrush& brush, QCPGraph * graph /*= nullptr*/)
{
    if (graph)
    {
        graph->setBrush(brush);
    }
    else
    {
        if (m_pPlot->graph())
        {
            m_pPlot->graph()->setBrush(brush);
        }
    }
}

QCPAxis * BasePlot::GetAxis(QCPAxis::AxisType axis)
{
    switch (axis)
    {
    case QCPAxis::atLeft:
        return m_pPlot->yAxis;
        break;
    case QCPAxis::atTop:
        return m_pPlot->xAxis2;
        break;
    case QCPAxis::atRight:
        return m_pPlot->yAxis2;
        break;
    case QCPAxis::atBottom:
        return m_pPlot->xAxis;
        break;
    default:
        return m_pPlot->xAxis;
        break;
    }
}

void BasePlot::SetGridVisible(bool visible)
{
    if (QCPLayer * gridLayer = m_pPlot->layer(QStringLiteral("grid")))
    {
        gridLayer->setVisible(visible);
    }
}

void BasePlot::SetAxisPen(QCPAxis::AxisTypes axse, const QPen & pen)
{
    if (axse.testFlag(QCPAxis::atLeft))
    {
        GetAxis(QCPAxis::atLeft)->setBasePen(pen);
    }
    if(axse.testFlag(QCPAxis::atTop))
    {
        GetAxis(QCPAxis::atTop)->setBasePen(pen);
    }
    if(axse.testFlag(QCPAxis::atRight))
    {
        GetAxis(QCPAxis::atRight)->setBasePen(pen);
    }
    if(axse.testFlag(QCPAxis::atBottom))
    {
        GetAxis(QCPAxis::atBottom)->setBasePen(pen);
    }
}

void BasePlot::SetAxisTickStep(QCPAxis::AxisTypes axse, int step)
{
    if (axse.testFlag(QCPAxis::atLeft))
    {
        GetAxis(QCPAxis::atLeft)->setTickStep(step);
    }
    if (axse.testFlag(QCPAxis::atTop))
    {
		GetAxis(QCPAxis::atTop)->setTickStep(step);
    }
    if (axse.testFlag(QCPAxis::atRight))
    {
		GetAxis(QCPAxis::atRight)->setTickStep(step);
    }
    if (axse.testFlag(QCPAxis::atBottom))
    {
		GetAxis(QCPAxis::atBottom)->setTickStep(step);
    }
}

void BasePlot::SetAxisPadding(QCPAxis::AxisType type, int padding)
{
	GetAxis(type)->setTickLabelPadding(padding);
}

void BasePlot::InitializeUI()
{
    QVBoxLayout * mainLayout = new QVBoxLayout;
    m_pPlot = new QCustomPlot;

    mainLayout->setMargin(0);
    mainLayout->addWidget(m_pPlot);

    setLayout(mainLayout);
}

bool BasePlot::RegisiterBrotherRange(QCPAxis::AxisType type, BasePlot * plot)
{
	//���ò���
	if (plot->GetAxis(type)->tickStep() != GetAxis(type)->tickStep())
	{
		plot->GetAxis(type)->setTickStep(GetAxis(type)->tickStep());
	}

	//���ý�����Ϊ
	//if (plot->m_pPlot->interactions() != m_pPlot->interactions())
	//{
	//	plot->m_pPlot->setInteractions(m_pPlot->interactions());
	//}

	if (BasePlot::m_BrotherAxisRange.find(type) == BasePlot::m_BrotherAxisRange.end())
	{
		BasePlot::m_BrotherAxisRange[type].push_back(this);
		BasePlot::m_BrotherAxisRange[type].push_back(plot);
	}
	else
	{
		auto iter = std::find(BasePlot::m_BrotherAxisRange[type].begin(), BasePlot::m_BrotherAxisRange[type].end(), plot);
		if (iter == BasePlot::m_BrotherAxisRange[type].end())
		{
			BasePlot::m_BrotherAxisRange[type].push_back(plot);
		}
	}
	return true;
}

bool BasePlot::UnregisiterBrotherRange(QCPAxis::AxisType type, BasePlot * plot)
{
	if (BasePlot::m_BrotherAxisRange.find(type) == BasePlot::m_BrotherAxisRange.end())
	{
		auto iter = std::find(BasePlot::m_BrotherAxisRange[type].begin(), BasePlot::m_BrotherAxisRange[type].end(), plot);
		if (iter == BasePlot::m_BrotherAxisRange[type].end())
		{
			BasePlot::m_BrotherAxisRange[type].erase(iter);
			if (BasePlot::m_BrotherAxisRange[type].size() == 0)
			{
				BasePlot::m_BrotherAxisRange.erase(type);
			}
		}
	}
	else
	{
		return false;
	}
}

