#ifndef PLOTWIDGET_H
#define PLOTWIDGET_H

#include <memory>
#include <functional>

#include <QtGui/QColor>

#include <QtWidgets/QWidget>

namespace QCP
{
//	Q_DECLARE_OPERATORS_FOR_FLAGS(QCP::WindowFlags);

	enum WindowFlag	{
		NOTHING = 0,
		TITLE = 0x1,
		ZOOM_OUT = 0x2,
		ZOOM_IN = 0x4,
		SETUP = 0x8,
		FRUSH = 0x10,
		CLOSE = 0x20,

		KLINE = TITLE | ZOOM_OUT | ZOOM_IN | SETUP | FRUSH,
		QUOTA = TITLE | SETUP | CLOSE,
	};

	Q_DECLARE_FLAGS(WindowFlags, WindowFlag);
};

/// ������ָ��С��Ŀ

class QuotaItem : public QWidget
{
	Q_OBJECT

signals:
	void ItemClicked(const QString & id);

public:
	//quotaָ�����ƣ���ΪΨһid����֧���޸�
	QuotaItem(const QString & quota, double value, QWidget * parent = nullptr);
	~QuotaItem();

public:
	void SetValue(double value);
	double GetValue() const;
	void SetTextColor(const QColor & color);
	QColor GetTextColor() const;

private:
	struct QuotaItemPrivate;
	std::unique_ptr<QuotaItemPrivate> _p;
};

/// ��������װ�˴��б������Ĵ��ڣ���Ҫ����չʾͼ�����ڣ�ʹ��SetContentWidget�ӿڽ���ͼ����������

class PlotWidget : public QWidget
{
	Q_OBJECT

public:
	PlotWidget(QWidget * parent = nullptr, QCP::WindowFlags flags = QCP::KLINE);
	~PlotWidget();

public:
	void SetTitleName(const QString & name);
	void SetContentWidget(QWidget * widget);
	void RegisterToolBarCallback(std::function<void (QCP::WindowFlag flag)> & onclicked);
	void AddQuota(const QString & quota, double value);
	void RemoveQuota(const QString & quota);

private slots:
	void ToobarButtonClicked(int);

private:
	void InitializeUI();
	void SetupTitile();
	void SetupContentWidget();

private:
	struct PlotWidgetPrivate;
	std::unique_ptr<PlotWidgetPrivate> _p;
};

#endif // PLOTWIDGET_H
