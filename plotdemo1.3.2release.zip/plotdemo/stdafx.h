#include <QtWidgets> 

void FindNearlyindex(double min, double max, double step, double value, double & resultValue);
