#include "stdafx.h"

#include "BasePlot.h"
#include "GraphPlot.h"

#include "CrossLinePlot.h"

std::vector<CrossLinePlot *>CrossLinePlot::m_BrotherLine;

namespace QCP
{
	enum LineState
	{
		E_NULL = 0x1,
		E_Vertical = 0x2,
		E_Horizontal = 0x4,
		E_ALL = E_Vertical + E_Horizontal
	};
	Q_DECLARE_FLAGS(LineStates, LineState);
}

struct CrossLinePlot::CrossLinePlotPrivate
{
	QCP::LineStates m_bIsVisible;
	bool m_bLeftButtonPress = false;
	double m_iAxisXValue = -1;
	QPoint m_MousePoint;
	QCPPainter * m_pPainter = nullptr;
	QPen m_Pen = QPen(Qt::red, 1, Qt::DashDotLine);
	BasePlot * m_pParentPlot = nullptr;
};

CrossLinePlot::CrossLinePlot(BasePlot * basePlot, QCustomPlot * plot)
	: QCPLayerable(plot)
	, _p(new CrossLinePlotPrivate)
{
	_p->m_pParentPlot = basePlot;

	mParentPlot->setSecondLayer(this, LayerName());

	connect(mParentPlot, &QCustomPlot::mousePress, this, [this](QMouseEvent * event){
		if (event->button() & Qt::LeftButton)
		{
			_p->m_bLeftButtonPress = true;
		}
	});
	connect(mParentPlot, &QCustomPlot::mouseRelease, this, [this](QMouseEvent * event){
		if (event->button() & Qt::LeftButton)
		{
			_p->m_bLeftButtonPress = false;
		}
	});
	connect(mParentPlot, &QCustomPlot::mouseMove, this, [this](QMouseEvent * event){
		_p->m_MousePoint = event->pos();
// 		if (_p->m_bLeftButtonPress == false)
// 		{
// 			return;
// 		}
		if (_p->m_bIsVisible.testFlag(QCP::E_NULL) == false)
		{
			for (CrossLinePlot * crossline : CrossLinePlot::m_BrotherLine)
			{
				if (crossline != this)
				{
					crossline->SyncLinePosition(_p->m_MousePoint, _p->m_iAxisXValue);
				}
			}
			mParentPlot->reDrawLayer(LayerName());
		}
		if (_p->m_pParentPlot)
		{
			_p->m_pParentPlot->MoveTipLabel(QPoint(_p->m_iAxisXValue, _p->m_MousePoint.y()));
		}
	});

	connect(mParentPlot, &QCustomPlot::mouseLeave, this, [this](QEvent * event){
		_p->m_bIsVisible = QCP::E_NULL;
		mParentPlot->reDrawLayer(LayerName());
		for (CrossLinePlot * crossline : CrossLinePlot::m_BrotherLine)
		{
			if (crossline != this)
			{
				crossline->SyncLinePosition(QPoint(), _p->m_iAxisXValue);
			}
		}
	});
	connect(mParentPlot, &QCustomPlot::mouseEnter, this, [this](QEvent * event){
		_p->m_bIsVisible = QCP::E_ALL;
		mParentPlot->reDrawLayer(LayerName());
	}); 

	QVector<qreal> dashes;
	qreal space = 4;
	dashes << 3 << space << 9 << space;
	_p->m_Pen.setDashPattern(dashes);
}

CrossLinePlot::~CrossLinePlot()
{

}

QString CrossLinePlot::LayerName() const
{
	return QStringLiteral("crossline");
}

void CrossLinePlot::SetVisible(bool visible)
{
	QCPLayer * layer = mParentPlot->layer(LayerName());
	if (layer)
	{
		layer->setVisible(visible);
	}
}

void CrossLinePlot::SetPen(const QPen & pen)
{
	_p->m_Pen = pen;
}

bool CrossLinePlot::MouseButtonDown() const
{
	return _p->m_bLeftButtonPress;
}

bool CrossLinePlot::GetLineVisible(Qt::Orientation orientation) const
{
	switch (orientation)
	{
	case Qt::Horizontal:
		return _p->m_bIsVisible.testFlag(QCP::E_Horizontal);
		break;
	case Qt::Vertical:
		return _p->m_bIsVisible.testFlag(QCP::E_Vertical);
		break;
	}
}

void CrossLinePlot::SetLineVisible(Qt::Orientation orientation, bool visible)
{

}

void CrossLinePlot::draw(QCPPainter * painter)
{
	Q_UNUSED(painter);

	_p->m_pPainter = painter;
	_p->m_pPainter->setPen(_p->m_Pen);

	if (GraphPlot * plot = dynamic_cast<GraphPlot *>(_p->m_pParentPlot))
	{
		if (_p->m_bIsVisible.testFlag(QCP::E_Vertical))
		{
			DrawLine(mParentPlot->xAxis, Qt::Vertical);
			plot->SetToopTipVisible(QCPAxis::atBottom, true);
		}
		if (_p->m_bIsVisible.testFlag(QCP::E_Horizontal))
		{
			DrawLine(mParentPlot->yAxis, Qt::Horizontal);
			plot->SetToopTipVisible(QCPAxis::atLeft | QCPAxis::atRight, true);
		}
		if (_p->m_bIsVisible.testFlag(QCP::E_NULL))
		{
			plot->SetToopTipVisible(QCPAxis::atLeft | QCPAxis::atRight | QCPAxis::atBottom, false);
		}
	}
}

void CrossLinePlot::DrawLine(QCPAxis * axis, Qt::Orientation orientation)
{
	if (axis == nullptr)
	{
		return;
	}
// 	if (axis->axisRect()->rect().contains(_p->m_MousePoint) == false)
// 	{
// 		return;
// 	}
	if (_p->m_MousePoint.isNull())
	{
		return;
	}
	int lowTick = axis->mLowestVisibleTick;
	int highTick = axis->mHighestVisibleTick;

	double pret, t;
	double epsilon = axis->range().size()*1E-6; 
	double minLength = 100000;

	if (axis->mTickVector.size() < 2)
	{
		return;
	}

	QVector<double> sumTick = axis->mTickVector.mid(lowTick, highTick - lowTick + 1);
	sumTick += axis->mSubTickVector;
	if (sumTick.size() <= 2)
	{
		//��־
		return;
	}
	qSort(sumTick.begin(), sumTick.end());
	if (orientation == Qt::Vertical)
	{
		double step = (double)(axis->mTickVector.at(1) - axis->mTickVector.at(0)) / (axis->subTickCount() + 1);
		double value, tickPos;
		FindNearlyindex(sumTick[0], sumTick[sumTick.size() - 1], step, axis->pixelToCoord(_p->m_MousePoint.x()), value);
		tickPos = axis->coordToPixel(value);
		_p->m_iAxisXValue = tickPos;
		
		QLineF verLine(tickPos, axis->axisRect()->outerRect().bottom(), tickPos, axis->axisRect()->outerRect().top());
		_p->m_pPainter->drawLine(verLine);
	}
	else
	{
		t = _p->m_MousePoint.y();
		if (t > axis->axisRect()->outerRect().bottom())
		{
			t = axis->axisRect()->outerRect().bottom();
		}
		if (t < axis->axisRect()->outerRect().top())
		{
			t = axis->axisRect()->outerRect().top();
		}
		QLineF horLine(axis->axisRect()->outerRect().left(), t, axis->axisRect()->outerRect().right(), t);
		_p->m_pPainter->drawLine(horLine);
	}
}

void CrossLinePlot::SyncLinePosition(const QPoint & pos, double x)
{
	if (pos.isNull())
	{
		_p->m_bIsVisible = QCP::E_NULL;
	}
	else
	{
		_p->m_bIsVisible = QCP::E_Vertical;
	}
	_p->m_MousePoint = pos;
	_p->m_iAxisXValue = x;

	mParentPlot->reDrawLayer(LayerName());

	if (_p->m_pParentPlot)
	{
		_p->m_pParentPlot->MoveTipLabel(QPoint(_p->m_iAxisXValue, _p->m_MousePoint.y()));
	}
}

bool CrossLinePlot::RegisiterBortherLine(CrossLinePlot * line)
{
	if (std::find(CrossLinePlot::m_BrotherLine.begin(), CrossLinePlot::m_BrotherLine.end(), this) == CrossLinePlot::m_BrotherLine.end())
	{
		CrossLinePlot::m_BrotherLine.push_back(this);
	}

	auto iter = std::find(CrossLinePlot::m_BrotherLine.begin(), CrossLinePlot::m_BrotherLine.end(), line);
	if (iter == CrossLinePlot::m_BrotherLine.end())
	{
		CrossLinePlot::m_BrotherLine.push_back(line);
		return true;
	}

	return false;
}

bool CrossLinePlot::UnregisiterBortherLine(CrossLinePlot * line)
{
	auto iter = std::find(CrossLinePlot::m_BrotherLine.begin(), CrossLinePlot::m_BrotherLine.end(), line);
	if (iter != CrossLinePlot::m_BrotherLine.end())
	{
		CrossLinePlot::m_BrotherLine.erase(iter);
		return true;
	}

	return false;
}
