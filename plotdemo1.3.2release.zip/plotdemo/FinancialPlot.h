#ifndef FINANCIALPLOT_H
#define FINANCIALPLOT_H

#include "GraphPlot.h"


class FinancialPlot : public GraphPlot
{
	Q_OBJECT

public:
	FinancialPlot(QWidget * parent = nullptr);
	~FinancialPlot();

public: 
	void SetInteractions(const QCP::Interactions & interactions);//���ý���ģʽ ��������������
	void SetDragOrientation(Qt::Orientations orientations);//������קʱ����  
	void SetZoomOrientation(Qt::Orientations orientations);
	void SetCursorShape(Qt::CursorShape shape);

private:
	struct FinancialPlotPrivate;
	std::unique_ptr<FinancialPlotPrivate> _p;
};

#endif // FINANCIALPLOT_H
