#include "stdafx.h"

#include <QtCore/QSignalMapper>

#include <QtGui/QPalette>

#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QToolButton>

#include "GraphPlot.h"

#include "PlotWidget.h"

struct QuotaItem::QuotaItemPrivate
{
	QToolButton * m_pButton = nullptr;
	QLabel * m_pTextValue = nullptr;
};

QuotaItem::QuotaItem(const QString & quota, double value, QWidget * parent /*= nullptr*/)
	: QWidget(parent)
	, _p(new QuotaItemPrivate)
{
	QHBoxLayout * mainLayout = new QHBoxLayout;
	_p->m_pButton = new QToolButton;
	_p->m_pTextValue = new QLabel;

	connect(_p->m_pButton, &QToolButton::clicked, this, [this]{
		emit ItemClicked(_p->m_pButton->text().remove(QStringLiteral(":")));
	});

	_p->m_pButton->setText(quota);
	SetValue(value);

	mainLayout->setMargin(0);
	mainLayout->setSpacing(0);

	mainLayout->addWidget(_p->m_pButton);
	mainLayout->addWidget(_p->m_pTextValue);

	SetTextColor(Qt::red);

	setLayout(mainLayout);
}

QuotaItem::~QuotaItem()
{

}

void QuotaItem::SetValue(double value)
{
	_p->m_pTextValue->setText(QString::number(value, 'f', 3));
}

double QuotaItem::GetValue() const
{
	return _p->m_pTextValue->text().toDouble();
}

void QuotaItem::SetTextColor(const QColor & color)
{
	QPalette palette = _p->m_pButton->palette();
	palette.setColor(QPalette::ButtonText, color);
	_p->m_pButton->setPalette(palette);

	palette = _p->m_pTextValue->palette();
	palette.setColor(QPalette::WindowText, color);
	_p->m_pTextValue->setPalette(palette);
}

QColor QuotaItem::GetTextColor() const
{
	return _p->m_pTextValue->palette().color(QPalette::WindowText);
}

struct PlotWidget::PlotWidgetPrivate
{
	QCP::WindowFlags m_Flags = QCP::NOTHING;
	QLabel * m_pTitleName = nullptr;
	QToolButton * m_pRefrush = nullptr;
	QToolButton * m_pZoomout = nullptr;
	QToolButton * m_pZoomin = nullptr;
	QToolButton * m_pSetup = nullptr;
	QSignalMapper * m_pBarClickedMap = nullptr;
	QVBoxLayout * m_pMainLayout = nullptr;//�����ڲ���
	QHBoxLayout * m_pTitleLayout = nullptr;//����������
	QHBoxLayout * m_pQuotaLayout = nullptr;//������ָ�겼��
	QWidget * m_pContentWidget = nullptr;

	std::function<void(QCP::WindowFlag flag)> * m_pToolbarCallback = nullptr;
};

PlotWidget::PlotWidget(QWidget * parent, QCP::WindowFlags flags)
	: QWidget(parent)
	, _p(new PlotWidgetPrivate)
{
	_p->m_Flags = flags;
	InitializeUI();
}

PlotWidget::~PlotWidget()
{

}

void PlotWidget::SetTitleName(const QString & name)
{
	_p->m_pTitleName->setText(name);
}

void PlotWidget::SetContentWidget(QWidget * widget)
{
	if (_p->m_pContentWidget)
	{
		delete _p->m_pMainLayout->takeAt(_p->m_pMainLayout->count() - 1);
		delete  _p->m_pContentWidget;
	}

	_p->m_pContentWidget = widget;

	SetupContentWidget();
}

void PlotWidget::RegisterToolBarCallback(std::function<void(QCP::WindowFlag flag)> & onclicked)
{
	_p->m_pToolbarCallback = &onclicked;
}

void PlotWidget::AddQuota(const QString & quota, double value)
{
	//����������ָ����ʾ
	QuotaItem * item = new QuotaItem(quota, value);
	_p->m_pQuotaLayout->addWidget(item);

	//����ͼ
	if (_p->m_pContentWidget)
	{
		if (GraphPlot * graphWidget = dynamic_cast<GraphPlot *>(_p->m_pContentWidget))
		{
			QCPGraph * graphItem = graphWidget->AddGraph();
			graphItem->setName(quota);//��ΪΨһ��ʾ
			graphWidget->SetPen(QPen(item->GetTextColor()));
		}
	}
}

void PlotWidget::RemoveQuota(const QString & quota)
{
	if (GraphPlot * graphWidget = dynamic_cast<GraphPlot *>(_p->m_pContentWidget))
	{
		graphWidget->RemoveGraph(quota);
	}
}

void PlotWidget::ToobarButtonClicked(int index)
{
	QCP::WindowFlag flag = (QCP::WindowFlag)index;
	if (_p->m_Flags.testFlag(flag))
	{
		if (_p->m_pToolbarCallback)
		{
			(*_p->m_pToolbarCallback)(flag);
		}

		switch (flag)
		{
		case QCP::TITLE:
			break;
		case QCP::ZOOM_OUT:
			break;
		case QCP::ZOOM_IN:
			break;
		case QCP::SETUP:
			break;
		case QCP::FRUSH:
			break;
		case QCP::NOTHING:
			break;
		default:
			break;
		}
	}
}

void PlotWidget::InitializeUI()
{
	_p->m_pMainLayout = new QVBoxLayout;
	_p->m_pMainLayout->setMargin(0);
	_p->m_pMainLayout->setSpacing(0);

	//������
	SetupTitile();
	
	//���Ĵ���
	SetupContentWidget();

	setLayout(_p->m_pMainLayout);
}

void PlotWidget::SetupTitile()
{
	QWidget * titleWidget = new QWidget;
	titleWidget->setBackgroundRole(QPalette::HighlightedText);

	_p->m_pTitleLayout = new QHBoxLayout;
	_p->m_pQuotaLayout = new QHBoxLayout;

	_p->m_pTitleLayout->setMargin(0);
	_p->m_pTitleLayout->setSpacing(0);
	_p->m_pQuotaLayout->setMargin(0);
	_p->m_pQuotaLayout->setSpacing(0);

	_p->m_pBarClickedMap = new QSignalMapper;

	if (_p->m_Flags.testFlag(QCP::TITLE))
	{
		_p->m_pTitleName = new QLabel;
		_p->m_pBarClickedMap->setMapping(_p->m_pTitleName, QCP::TITLE);
		_p->m_pTitleName->setFixedSize(QSize(18, 18));
		_p->m_pTitleLayout->addWidget(_p->m_pTitleName);
	}
	_p->m_pTitleLayout->addLayout(_p->m_pQuotaLayout);
	_p->m_pTitleLayout->addStretch(1);
	if (_p->m_Flags.testFlag(QCP::FRUSH))
	{
		_p->m_pRefrush = new QToolButton;
		connect(_p->m_pRefrush, &QToolButton::clicked, _p->m_pBarClickedMap, static_cast<void (QSignalMapper:: *)()>(&QSignalMapper::map));
		_p->m_pBarClickedMap->setMapping(_p->m_pRefrush, QCP::FRUSH);
		_p->m_pRefrush->setFixedSize(QSize(18, 18));
		_p->m_pTitleLayout->addWidget(_p->m_pRefrush);
	}
	if (_p->m_Flags.testFlag(QCP::ZOOM_OUT))
	{
		_p->m_pZoomout = new QToolButton;
		connect(_p->m_pZoomout, &QToolButton::clicked, _p->m_pBarClickedMap, static_cast<void (QSignalMapper:: *)()>(&QSignalMapper::map));
		_p->m_pBarClickedMap->setMapping(_p->m_pZoomout, QCP::ZOOM_OUT);
		_p->m_pZoomout->setFixedSize(QSize(18, 18));
		_p->m_pTitleLayout->addWidget(_p->m_pZoomout);
	}
	if (_p->m_Flags.testFlag(QCP::ZOOM_IN))
	{
		_p->m_pZoomin = new QToolButton;
		connect(_p->m_pZoomin, &QToolButton::clicked, _p->m_pBarClickedMap, static_cast<void (QSignalMapper:: *)()>(&QSignalMapper::map));
		_p->m_pBarClickedMap->setMapping(_p->m_pZoomin, QCP::ZOOM_IN);
		_p->m_pZoomin->setFixedSize(QSize(18, 18));
		_p->m_pTitleLayout->addWidget(_p->m_pZoomin);
	}
	if (_p->m_Flags.testFlag(QCP::SETUP))
	{
		_p->m_pSetup = new QToolButton;
		connect(_p->m_pSetup, &QToolButton::clicked, _p->m_pBarClickedMap, static_cast<void (QSignalMapper:: *)()>(&QSignalMapper::map));
		_p->m_pBarClickedMap->setMapping(_p->m_pSetup, QCP::SETUP);
		_p->m_pSetup->setFixedSize(QSize(18, 18));
		_p->m_pTitleLayout->addWidget(_p->m_pSetup);
	}

	connect(_p->m_pBarClickedMap, static_cast<void (QSignalMapper:: *)(int)>(&QSignalMapper::mapped),
		this, static_cast<void (PlotWidget:: *)(int)>(&PlotWidget::ToobarButtonClicked));

	titleWidget->setLayout(_p->m_pTitleLayout);
	_p->m_pMainLayout->addWidget(titleWidget);
}

void PlotWidget::SetupContentWidget()
{
	if (_p->m_pContentWidget == nullptr)
	{
		_p->m_pContentWidget = new QWidget(this);
	}
	_p->m_pMainLayout->addWidget(_p->m_pContentWidget, 1);
}

