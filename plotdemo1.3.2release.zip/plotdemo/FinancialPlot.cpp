#include "stdafx.h"

#include "FinancialPlot.h"

struct FinancialPlot::FinancialPlotPrivate
{
	Qt::CursorShape m_eShape;
};

FinancialPlot::FinancialPlot(QWidget * parent)
	: GraphPlot(parent)
	, _p(new FinancialPlotPrivate)
{
	SetDragOrientation(Qt::Horizontal);
	SetZoomOrientation(Qt::Horizontal);
}

FinancialPlot::~FinancialPlot()
{

}

void FinancialPlot::SetInteractions(const QCP::Interactions & interactions)
{
	m_pPlot->setInteractions(interactions);
}

void FinancialPlot::SetDragOrientation(Qt::Orientations orientations)
{
	m_pPlot->axisRect()->setRangeDrag(orientations);
}

void FinancialPlot::SetZoomOrientation(Qt::Orientations orientations)
{
	m_pPlot->axisRect()->setRangeZoom(orientations);
}

void FinancialPlot::SetCursorShape(Qt::CursorShape shape)
{
	_p->m_eShape = shape;
	switch (_p->m_eShape)
	{
	case Qt::ClosedHandCursor:
		SetInteractions(m_pPlot->interactions() | QCP::iRangeDrag | QCP::iRangeZoom);
		break;
	case Qt::ArrowCursor:
		SetInteractions(m_pPlot->interactions() & ~QCP::iRangeDrag & ~QCP::iRangeZoom);
		break;
	default:
		SetInteractions(m_pPlot->interactions() & ~QCP::iRangeDrag & ~QCP::iRangeZoom);
		break;
	}
	setCursor(_p->m_eShape);
}
